package finalAssessment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * The Competitor class manages player data and scores.
 */
public class Competitor {
    // Database connection constants
    static final String DB_URL = "jdbc:mysql//localhost:3306"; 
    static final String USER = "root";
    static final String PASS = "1234";

    /**
     * Ranks players based on their scores for the selected difficulty level.
     *
     * @param selectedLevel The difficulty level (Beginner, Intermediate, Advanced).
     * @return A list of ranked players with their scores.
     */
    
    public static List<String[]> rankScore(String selectedLevel) {
        String selectQuery = "";

        if (selectedLevel.equalsIgnoreCase("Beginner")) {
            selectQuery = "SELECT user_name, beginner_score FROM players WHERE beginner_status = 'y' ORDER BY beginner_score DESC";
        } else if (selectedLevel.equalsIgnoreCase("Intermediate")) {
            selectQuery = "SELECT user_name, intermediate_score FROM players WHERE intermediate_status = 'y' ORDER BY intermediate_score DESC";
        } else if (selectedLevel.equalsIgnoreCase("Advanced")) {
            selectQuery = "SELECT user_name, advance_score FROM players WHERE advance_status = 'y' ORDER BY advance_score DESC";
        }

        List<String[]> rankedPlayers = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(selectQuery);
             ResultSet rs = stmt.executeQuery()) {

            int rank = 1;
            while (rs.next()) {
                String userName = rs.getString("user_name");
                int score = rs.getInt(2);
                
                String noOfCorrect = "0";

                rankedPlayers.add(new String[]{String.valueOf(rank), userName, String.valueOf(score), noOfCorrect});
                rank++;
            }

        } catch (SQLException e) {
            System.err.println("Error fetching ranked scores: " + e.getMessage());
        }

        return rankedPlayers;
    }
    
    /**
     * Saves the score of a player for the selected difficulty level.
     *
     * @param selectedLevel The difficulty level (beginner, intermediate, advanced).
     * @param user_name The name of the player.
     * @param score The score to be saved.
     */
    
    public static void savescore(String selectedLevel, String user_name, int score) {
        String updateQuery = "";
        
        if (selectedLevel.equals("beginner")) {
            updateQuery = "UPDATE players SET beginner_status = 'y', beginner_score = ? WHERE user_name = ?";
        } else if (selectedLevel.equals("intermediate")) {
            updateQuery = "UPDATE players SET intermediate_status = 'y', intermediate_score = ? WHERE user_name = ?";
        } else if (selectedLevel.equals("advanced")) {
            updateQuery = "UPDATE players SET advance_status = 'y', advance_score = ? WHERE user_name = ?";
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

            stmt.setInt(1, score); 
            stmt.setString(2, user_name);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Score updated successfully!");
            } else {
                System.out.println("No user found with the username: " + user_name);
            }

        } catch (SQLException e) {
            System.err.println("Error updating score: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid score format: " + e.getMessage());
        }
    }

    /**
     * Saves a new player or updates an existing player's status.
     *
     * @param user_name The name of the player.
     * @param status The status of the player (beginner, intermediate, advanced).
     */
    
    public static void save(String user_name, String status) {
        String checkQuery = "SELECT COUNT(*) FROM players WHERE user_name = ?";
        
        String insertQueryBeginner = "INSERT INTO players (user_name, beginner_score, beginner_status, intermediate_score, intermediate_status, advance_score, advance_status) VALUES (?, 0, 'y', 0, 'n', 0, 'n')";
        String insertQueryIntermediate = "INSERT INTO players (user_name, beginner_score, beginner_status, intermediate_score, intermediate_status, advance_score, advance_status) VALUES (?, 0, 'n', 0, 'y', 0, 'n')";
        String insertQueryAdvance = "INSERT INTO players (user_name, beginner_score, beginner_status, intermediate_score, intermediate_status, advance_score, advance_status) VALUES (?, 0, 'n', 0, 'n', 0, 'y')";

        String updateQueryBeginner = "UPDATE players SET beginner_status = 'y', beginner_score = 0 WHERE user_name = ?";
        String updateQueryIntermediate = "UPDATE players SET intermediate_status = 'y', intermediate_score = 0 WHERE user_name = ?";
        String updateQueryAdvanced = "UPDATE players SET advance_status = 'y', advance_score = 0 WHERE user_name = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            
            // Check if the user already exists
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                checkStmt.setString(1, user_name);
                ResultSet rs = checkStmt.executeQuery();
                
                // If the user exists, update based on status
                if (rs.next() && rs.getInt(1) > 0) {
                    String updateQuery = "";
                    
                    // Choose the correct update query based on the status
                    switch (status.toLowerCase()) {
                        case "beginner":
                            updateQuery = updateQueryBeginner;
                            break;
                        case "intermediate":
                            updateQuery = updateQueryIntermediate;
                            break;
                        case "advanced":
                            updateQuery = updateQueryAdvanced;
                            break;
                        default:
                            System.out.println("Invalid status");
                            return;
                    }

                    // Execute the update
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                        updateStmt.setString(1, user_name);  // Set user_name for update
                        int rowsUpdated = updateStmt.executeUpdate();
                        if (rowsUpdated > 0) {
                            System.out.println("User " + user_name + " updated with " + status + " status.");
                        }
                    }
                } else {
                    // If the user doesn't exist, insert a new record based on status
                    String insertQuery = "";
                    
                    // Choose the correct insert query based on the status
                    switch (status.toLowerCase()) {
                        case "beginner":
                            insertQuery = insertQueryBeginner;
                            break;
                        case "intermediate":
                            insertQuery = insertQueryIntermediate;
                            break;
                        case "advanced":
                            insertQuery = insertQueryAdvance;
                            break;
                        default:
                            System.out.println("Invalid status for new player");
                            return;
                    }

                    // Execute the insert
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                        insertStmt.setString(1, user_name);  // Set user_name
                        int rowsInserted = insertStmt.executeUpdate();
                        if (rowsInserted > 0) {
                            System.out.println("New user " + user_name + " inserted with " + status + " status.");
                        }
                    }
                }
            }
            
        } catch (SQLException e) {
            System.out.println("Error saving or updating player: " + e.getMessage());
        }
    }

public static void main(String[] args) {
    // Save player with "JohnDoe" and set beginner status to "y"
	rankScore("beginner"); 


}

}

