package finalAssessment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class QuestionTest {

    @Test
    public void testSaveQuestion() {
        // Arrange
        String questionText = "What is the capital of France?";
        String option1 = "Berlin";
        String option2 = "Madrid";
        String option3 = "Paris";
        String rightOption = "Paris";
        Question.DifficultyLevel difficultyLevel = Question.DifficultyLevel.BEGINNER;

        // Act
        Question.save(option1, option2, option3, rightOption, difficultyLevel, questionText);

        // Assert
        // Verify that the question was saved correctly
        // This is a placeholder assertion; implement actual verification logic
        assertTrue(true); // Replace with actual verification
    }

    @Test
    public void testUpdateQuestion() {
        // Arrange
        int questionId = 1; // Assume this ID exists
        String updatedQuestionText = "What is the capital of Germany?";
        String option1 = "Berlin";
        String option2 = "Madrid";
        String option3 = "Paris";
        String rightOption = "Berlin";
        Question.DifficultyLevel difficultyLevel = Question.DifficultyLevel.BEGINNER;

        // Act
        Question.update(questionId, option1, option2, option3, rightOption, difficultyLevel, updatedQuestionText);

        // Assert
        // Verify that the question was updated correctly
        // This is a placeholder assertion; implement actual verification logic
        assertTrue(true); // Replace with actual verification
    }

    @Test
    public void testDeleteQuestion() {
        // Arrange
        int questionId = 1; // Assume this ID exists

        // Act
        Question.delete(questionId);

        // Assert
        // Verify that the question was deleted correctly
        // This is a placeholder assertion; implement actual verification logic
        assertTrue(true); // Replace with actual verification
    }
}