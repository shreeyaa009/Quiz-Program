package finalAssessment;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.sql.SQLException;


public class Data_Table extends JFrame {

 private static final long serialVersionUID = 1L;
 private JPanel contentPane;
 private JTable table;
 private DefaultTableModel tableModel;
 /**
  * Launch the application.
  */
 public static void main(String[] args) {
     EventQueue.invokeLater(new Runnable() {
         public void run() {
             try {
                 Data_Table frame = new Data_Table();
                 frame.setVisible(true);
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
     });
 }

 /**
  * Create the frame.
  */
 public Data_Table() {
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setBounds(100, 100, 750, 441);
     contentPane = new JPanel();
     contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
     setContentPane(contentPane);

     // Define Table Columns (Now Includes ID)
     String[] columns = {"ID", "Level", "Question", "Option1", "Option2", "Option3", "Right"};
     
     // Table Model
     tableModel = new DefaultTableModel(columns, 0);
     contentPane.setLayout(null);
     table = new JTable(tableModel);
     JScrollPane scrollPane = new JScrollPane(table);
     scrollPane.setBounds(304, 33, 395, 325);
     contentPane.add(scrollPane);

     // Panel for Buttons
     JPanel buttonPanel = new JPanel();
     buttonPanel.setBounds(-42, 33, 347, 196);

     // ADD Question Button
     JButton AddQuestion = new JButton("ADD Question");
     AddQuestion.setBounds(57, 10, 143, 29);
     AddQuestion.setFont(new Font("Tahoma", Font.BOLD, 16));
     AddQuestion.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             showAddQuestionDialog();
         }
     });
     buttonPanel.setLayout(null);
     buttonPanel.add(AddQuestion);

     // UPDATE Question Button
     JButton UpdateQuestion = new JButton("UPDATE");
     UpdateQuestion.setBounds(67, 68, 97, 29);
     UpdateQuestion.setFont(new Font("Tahoma", Font.BOLD, 16));
     UpdateQuestion.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             updateSelectedQuestion();
         }
     });
     buttonPanel.add(UpdateQuestion);

     // DELETE Question Button
     JButton DeleteQuestion = new JButton("DELETE");
     DeleteQuestion.setBounds(67, 128, 91, 29);
     DeleteQuestion.setFont(new Font("Tahoma", Font.BOLD, 16));
     DeleteQuestion.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             deleteSelectedQuestion();
         }
     });
     buttonPanel.add(DeleteQuestion);

     // Add button panel at the bottom
     contentPane.add(buttonPanel);
 }
 
 public void loadQuestionsFromDatabase() {
 	tableModel.setRowCount(0);
 	String query = "SELECT * FROM questions";
 	try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()){
 		 while (rs.next()) {
              int id = rs.getInt("id");
              String level = rs.getString("difficulty_level");
              String question = rs.getString("question");
              String option1 = rs.getString("option1");
              String option2 = rs.getString("option2");
              String option3 = rs.getString("option3");
              String rightOption = rs.getString("right_option");

              tableModel.addRow(new Object[]{id, level, question, option1, option2, option3, rightOption});
          }
 		
 		
 	}catch(SQLException e) {
         System.err.println("Error loading questions: " + e.getMessage());    		
 	}
 	
 }

 // Method to Show Add Question Popup
 private void showAddQuestionDialog() {
     JDialog dialog = new JDialog(this, "Add Question", true);
     dialog.setSize(400, 350);
     dialog.getContentPane().setLayout(new GridLayout(7, 2, 5, 5));

     JLabel lblLevel = new JLabel("Level:");
     String[] levels = {"beginner", "intermediate", "advanced"};
     JComboBox<String> cmbLevel = new JComboBox<>(levels);

     JLabel lblQuestion = new JLabel("Question:");
     JTextField txtQuestion = new JTextField();
     JLabel lblOption1 = new JLabel("Option 1:");
     JTextField txtOption1 = new JTextField();
     JLabel lblOption2 = new JLabel("Option 2:");
     JTextField txtOption2 = new JTextField();
     JLabel lblOption3 = new JLabel("Option 3:");
     JTextField txtOption3 = new JTextField();
     JLabel lblRight = new JLabel("Right Option:");
     JTextField txtRight = new JTextField();

     JButton btnSave = new JButton("Save");
     btnSave.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             // Get values from input fields
//             String id = String.valueOf(idCounter++);
             String level = cmbLevel.getSelectedItem().toString().toUpperCase();
             String question = txtQuestion.getText();
             String option1 = txtOption1.getText();
             String option2 = txtOption2.getText();
             String option3 = txtOption3.getText();
             String right = txtRight.getText();
             Question.save(option1, option2, option3, right, Question.DifficultyLevel.valueOf(level), question);
             loadQuestionsFromDatabase();
             // Add row to table

             // Close the dialog
             dialog.dispose();
         }
     });

     dialog.getContentPane().add(lblLevel);
     dialog.getContentPane().add(cmbLevel);
     dialog.getContentPane().add(lblQuestion);
     dialog.getContentPane().add(txtQuestion);
     dialog.getContentPane().add(lblOption1);
     dialog.getContentPane().add(txtOption1);
     dialog.getContentPane().add(lblOption2);
     dialog.getContentPane().add(txtOption2);
     dialog.getContentPane().add(lblOption3);
     dialog.getContentPane().add(txtOption3);
     dialog.getContentPane().add(lblRight);
     dialog.getContentPane().add(txtRight);
     dialog.getContentPane().add(btnSave);

     dialog.setLocationRelativeTo(this);
     dialog.setVisible(true);
 }
 
 // Method to Delete Selected Question
 private void deleteSelectedQuestion() {
     int selectedRow = table.getSelectedRow();
     if (selectedRow != -1) {
         int id = (int) tableModel.getValueAt(selectedRow, 0);

         // Delete from database
         Question.delete(id);

         // Refresh table
         loadQuestionsFromDatabase();
     } else {
         JOptionPane.showMessageDialog(this, "Please select a row to delete.");
     }
 }
 

 

 // Method to Update Selected Question
 private void updateSelectedQuestion() {
     int selectedRow = table.getSelectedRow();
     if (selectedRow == -1) {
         JOptionPane.showMessageDialog(this, "Please select a row to update.");
         return;
     }

     // Fetch existing values
     String id = tableModel.getValueAt(selectedRow, 0).toString();
     String level = tableModel.getValueAt(selectedRow, 1).toString();
     String question = tableModel.getValueAt(selectedRow, 2).toString();
     String option1 = tableModel.getValueAt(selectedRow, 3).toString();
     String option2 = tableModel.getValueAt(selectedRow, 4).toString();
     String option3 = tableModel.getValueAt(selectedRow, 5).toString();
     String right = tableModel.getValueAt(selectedRow, 6).toString();

     // Open Update Dialog with Pre-Filled Values
     showUpdateDialog(selectedRow, id, level, question, option1, option2, option3, right);
 }

 private void showUpdateDialog(int rowIndex, String id, String level, String question, String option1, String option2, String option3, String right) {
     JDialog dialog = new JDialog(this, "Update Question", true);
     dialog.setSize(400, 350);
     dialog.getContentPane().setLayout(new GridLayout(7, 2, 5, 5));

     JLabel lblLevel = new JLabel("Level:");
     String[] levels = {"Beginner", "Intermediate", "Advanced"};
     JComboBox<String> cmbLevel = new JComboBox<>(levels);
     cmbLevel.setSelectedItem(level);

     JLabel lblQuestion = new JLabel("Question:");
     JTextField txtQuestion = new JTextField(question);
     JLabel lblOption1 = new JLabel("Option 1 (Wrong):");
     JTextField txtOption1 = new JTextField(option1);
     JLabel lblOption2 = new JLabel("Option 2 (Wrong):");
     JTextField txtOption2 = new JTextField(option2);
     JLabel lblOption3 = new JLabel("Option 3 (Wrong):");
     JTextField txtOption3 = new JTextField(option3);
     JLabel lblRight = new JLabel("Right Option:");
     JTextField txtRight = new JTextField(right);

     JButton btnSave = new JButton("Save");
     btnSave.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             try {
                 int questionId = Integer.parseInt(id); // Convert ID to int
                 String selectedLevel = cmbLevel.getSelectedItem().toString().toUpperCase(); // Convert to uppercase

                 // Update in the database
                 Question.update(questionId, txtOption1.getText(), txtOption2.getText(), txtOption3.getText(),
                                 txtRight.getText(), Question.DifficultyLevel.valueOf(selectedLevel), 
                                 txtQuestion.getText());

                 // Update values in the table
                 tableModel.setValueAt(cmbLevel.getSelectedItem().toString(), rowIndex, 1);
                 tableModel.setValueAt(txtQuestion.getText(), rowIndex, 2);
                 tableModel.setValueAt(txtOption1.getText(), rowIndex, 3);
                 tableModel.setValueAt(txtOption2.getText(), rowIndex, 4);
                 tableModel.setValueAt(txtOption3.getText(), rowIndex, 5);
                 tableModel.setValueAt(txtRight.getText(), rowIndex, 6);

                 // Close the dialog
                 dialog.dispose();

             } catch (NumberFormatException ex) {
                 JOptionPane.showMessageDialog(dialog, "Invalid question ID!", "Error", JOptionPane.ERROR_MESSAGE);
             } catch (IllegalArgumentException ex) {
                 JOptionPane.showMessageDialog(dialog, "Invalid difficulty level!", "Error", JOptionPane.ERROR_MESSAGE);
             }
         }
     });

     // Ensure the button is added to the dialog
     dialog.getContentPane().add(lblLevel);
     dialog.getContentPane().add(cmbLevel);
     dialog.getContentPane().add(lblQuestion);
     dialog.getContentPane().add(txtQuestion);
     dialog.getContentPane().add(lblOption1);
     dialog.getContentPane().add(txtOption1);
     dialog.getContentPane().add(lblOption2);
     dialog.getContentPane().add(txtOption2);
     dialog.getContentPane().add(lblOption3);
     dialog.getContentPane().add(txtOption3);
     dialog.getContentPane().add(lblRight);
     dialog.getContentPane().add(txtRight);
     dialog.getContentPane().add(new JLabel()); // Empty space
     dialog.getContentPane().add(btnSave);

     dialog.setVisible(true);
 } 
}
