package finalAssessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 756, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton Login = new JButton("ENTER");
		Login.setFont(new Font("Tahoma", Font.BOLD, 18));
		Login.setBackground(new Color(255, 255, 255));
		Login.setBounds(328, 187, 129, 43);
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		contentPane.setLayout(null);
		contentPane.add(Login);
		
		JTextArea Email = new JTextArea();
		Email.setFont(new Font("Monospaced", Font.PLAIN, 16));
		Email.setBounds(169, 140, 175, 35);
		contentPane.add(Email);
		
		JTextArea Password = new JTextArea();
		Password.setFont(new Font("Monospaced", Font.PLAIN, 16));
		Password.setBounds(495, 136, 237, 35);
		contentPane.add(Password);
		
		JLabel PASS = new JLabel("username : ");
		PASS.setFont(new Font("Tahoma", Font.BOLD, 18));
		PASS.setBounds(30, 138, 129, 28);
		contentPane.add(PASS);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPassword.setBounds(377, 138, 116, 28);
		contentPane.add(lblPassword);
		
		JLabel lblNewLabel = new JLabel("Page for Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel.setBounds(313, 40, 251, 43);
		contentPane.add(lblNewLabel);
		
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = Email.getText();
				String password = new String(Password.getText());
				boolean loginSuccess = UserLogin.loginUser(email, password);
				if (loginSuccess) {
					JOptionPane.showMessageDialog(null, "Login Successful!");
                    Dashboard dashboardFrame = new Dashboard();  
                    dashboardFrame.setVisible(true);             
                    dispose(); 
				} else {
					JOptionPane.showMessageDialog(null, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		
		
	}
}