package finalAssessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class Selection extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Selection frame = new Selection();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Selection() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 530, 331);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Selection");
        lblNewLabel.setBounds(154, 10, 124, 39);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        contentPane.add(lblNewLabel);

        JButton ADMIN = new JButton("ADMIN");
        ADMIN.setFont(new Font("Tahoma", Font.BOLD, 18));
        ADMIN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	Login loginFrame = new Login();  // Create an instance of the Login frame
                loginFrame.setVisible(true);     // Make the Login frame visible
                dispose(); 
            	
            }
        });
        ADMIN.setBounds(154, 76, 124, 61);
        contentPane.add(ADMIN);

        JButton PLAYER = new JButton("USER");
        PLAYER.setFont(new Font("Tahoma", Font.BOLD, 18));
        PLAYER.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the Player Dialog when clicked
                openPlayerDialog();
            }
        });
        PLAYER.setBounds(154, 164, 118, 61);
        contentPane.add(PLAYER);
    }

    /**
     * Open a dialog for the player to enter their name and select a level.
     */
    private void openPlayerDialog() {
        // Create a new frame for the dialog
        JFrame playerDialog = new JFrame("Player Information");
        playerDialog.setSize(400, 300);
        playerDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        playerDialog.getContentPane().setLayout(null);

        JLabel lblName = new JLabel("Player Name:");
        lblName.setBounds(50, 40, 100, 30);
        playerDialog.getContentPane().add(lblName);

        JTextField playerNameField = new JTextField();
        playerNameField.setBounds(160, 40, 150, 30);
        playerDialog.getContentPane().add(playerNameField);

        JLabel lblLevel = new JLabel("Select Level:");
        lblLevel.setBounds(50, 100, 100, 30);
        playerDialog.getContentPane().add(lblLevel);

        // Create a drop-down list for the levels
        String[] levels = { "beginner", "intermediate", "advanced" };
        JComboBox<String> levelComboBox = new JComboBox<>(levels);
        levelComboBox.setBounds(160, 100, 150, 30);
        playerDialog.getContentPane().add(levelComboBox);

        JButton playButton = new JButton("Play");
        playButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        playButton.setBounds(150, 180, 100, 40);
        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String playerName = playerNameField.getText();
                String selectedLevel = (String) levelComboBox.getSelectedItem();
                if (playerName.isEmpty()) {
                    JOptionPane.showMessageDialog(playerDialog, "Please enter your name!");
                } else {
                    List<Question> questionsList = Question.levelQuestion(selectedLevel);
                    if (questionsList.isEmpty()) {
                        JOptionPane.showMessageDialog(playerDialog, "No questions found for this level.");
                    } else {
                        openGamePage(playerName, selectedLevel, questionsList);
                        playerDialog.dispose();
                    }
                }
            }
        });
        playerDialog.getContentPane().add(playButton);
        playerDialog.setLocationRelativeTo(this); // Center the dialog
        playerDialog.setVisible(true);
    }
        /**
         * Open the game page (Play_Game) after the player info is submitted.
         */
        private void openGamePage(String playerName, String selectedLevel, List<Question> questionsList) {
        	Competitor.save(playerName,selectedLevel);
        	
            Play_Game gameFrame = new Play_Game(questionsList,selectedLevel,playerName );
            gameFrame.setVisible(true);
            this.dispose();
        }
}