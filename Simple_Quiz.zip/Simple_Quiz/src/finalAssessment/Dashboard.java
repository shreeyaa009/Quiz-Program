package finalAssessment;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;

public class Dashboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard frame = new Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Dashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
        JButton btnReport = new JButton("REPORT");
        btnReport.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnReport.setBounds(250, 226, 173, 42);
        btnReport.addActionListener(e -> {
            Report reportFrame = new Report();
            reportFrame.setVisible(true);
            reportFrame.listData();
            
            
        });
        contentPane.add(btnReport);
		
        JButton btnDataTable = new JButton("DATA ");
        btnDataTable.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnDataTable.setBounds(250, 98, 173, 42);
        btnDataTable.addActionListener(e -> {
            Data_Table dataTable = new Data_Table();
            dataTable.setVisible(true);
            dataTable.loadQuestionsFromDatabase();
            
            dispose(); // Close Dashboard
            
             
        });
        contentPane.add(btnDataTable);
	}

}
