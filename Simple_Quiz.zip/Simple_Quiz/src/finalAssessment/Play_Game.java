package finalAssessment;

import java.awt.Font;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The Play_Game class represents the quiz game interface where players answer questions.
 */
public class Play_Game extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private List<Question> questionsList;
    private int currentIndex = 0;
    private int score = 0;
    private String selectedLevel;
    private JLabel QuestionLabel;
    private JRadioButton Option1, Option2, Option3, Option4;
    private JButton Next_Button;
    private ButtonGroup group;
    private List<JRadioButton> optionButtons;
    private String user_name;
    
    /**
     * Constructs the game interface.
     *
     * @param questions The list of questions for the game.
     * @param selectedLevel The difficulty level of the questions.
     * @param user_name The name of the player.
     */

    public Play_Game(List<Question> questions,  String selectedLevel ,String user_name) {
        this.questionsList = new ArrayList<>(questions);
        Collections.shuffle(questionsList); // Shuffle questions
        this.selectedLevel = selectedLevel; 
        this.user_name = user_name;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 692, 502);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("GAME");
        lblNewLabel.setBounds(306, 10, 88, 25);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Question:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel_1.setBounds(113, 91, 100, 30);
        contentPane.add(lblNewLabel_1);

        QuestionLabel = new JLabel();
        QuestionLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        QuestionLabel.setBounds(229, 91, 400, 25);
        contentPane.add(QuestionLabel);

        Option1 = new JRadioButton();
        Option1.setFont(new Font("Tahoma", Font.BOLD, 18));
        Option1.setBounds(229, 144, 250, 21);
        contentPane.add(Option1);

        Option2 = new JRadioButton();
        Option2.setFont(new Font("Tahoma", Font.BOLD, 18));
        Option2.setBounds(229, 187, 250, 21);
        contentPane.add(Option2);

        Option3 = new JRadioButton();
        Option3.setFont(new Font("Tahoma", Font.BOLD, 18));
        Option3.setBounds(229, 225, 250, 21);
        contentPane.add(Option3);

        Option4 = new JRadioButton();
        Option4.setFont(new Font("Tahoma", Font.BOLD, 18));
        Option4.setBounds(229, 265, 250, 21);
        contentPane.add(Option4);

        group = new ButtonGroup();
        group.add(Option1);
        group.add(Option2);
        group.add(Option3);
        group.add(Option4);

        optionButtons = new ArrayList<>();
        optionButtons.add(Option1);
        optionButtons.add(Option2);
        optionButtons.add(Option3);
        optionButtons.add(Option4);

        Next_Button = new JButton("Next");
        Next_Button.setFont(new Font("Tahoma", Font.BOLD, 18));
        Next_Button.setBounds(544, 419, 100, 30);
        contentPane.add(Next_Button);

        Next_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
                showNextQuestion();
            }
        });

        showNextQuestion();
    }
    
    /**
     * Displays the next question in the game.
     */
    private void showNextQuestion() {
        if (currentIndex < questionsList.size()) {
            Question q = questionsList.get(currentIndex);
            QuestionLabel.setText(q.getQuestion());

            // Store options in a list
            List<String> options = new ArrayList<>();
            options.add(q.getOption1());
            options.add(q.getOption2());
            options.add(q.getOption3());
            options.add(q.getRightOption());

            // Shuffle the options randomly
            Collections.shuffle(options);

            // Assign shuffled options to radio buttons
            for (int i = 0; i < optionButtons.size(); i++) {
                optionButtons.get(i).setText(options.get(i));
            }

            group.clearSelection(); // Clear previous selection
            currentIndex++;
        } else {
            JOptionPane.showMessageDialog(this, "Game Over! Your Score: " + score);
            Competitor.savescore(selectedLevel, user_name,score);

            
            this.dispose();
        }
    }

    /**
     * Checks the selected answer and updates the score.
     */
    private void checkAnswer() {
        Question currentQuestion = questionsList.get(currentIndex - 1);
        String correctAnswer = currentQuestion.getRightOption();

        for (JRadioButton option : optionButtons) {
            if (option.isSelected() && option.getText().equals(correctAnswer)) {
                score++;
                break;
            }
        }
    }
}
