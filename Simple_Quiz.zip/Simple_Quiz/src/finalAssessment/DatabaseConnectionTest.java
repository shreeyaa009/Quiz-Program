package finalAssessment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnectionTest {

    @Test
    public void testGetConnection() {
        // Act
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Assert
            assertNotNull(conn);
            assertFalse(conn.isClosed());
        } catch (SQLException e) {
            fail("Connection should be established successfully: " + e.getMessage());
        }
    }
}