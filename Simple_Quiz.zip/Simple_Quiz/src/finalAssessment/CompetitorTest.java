package finalAssessment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

public class CompetitorTest {

    @Test
    public void testSaveScore() {
        // Arrange
        String userName = "testUser ";
        String level = "beginner";
        int score = 100;

        // Act
        Competitor.savescore(level, userName, score);

        // Assert
        // Implement actual verification logic here
        // For example, retrieve the score from the database and check if it matches
        assertTrue(true); // Replace with actual verification
    }

    @Test
    public void testRankScore() {
        // Arrange
        String level = "beginner";

        // Act
        List<String[]> rankedPlayers = Competitor.rankScore(level);

        // Assert
        assertNotNull(rankedPlayers);
        assertFalse(rankedPlayers.isEmpty());
        // Additional assertions can be made based on expected ranking
    }

    @Test
    public void testSaveNewPlayer() {
        // Arrange
        String userName = "newUser ";
        String status = "beginner";

        // Act
        Competitor.save(userName, status);

        // Assert
        // Verify that the player was saved correctly
        // This is a placeholder assertion; implement actual verification logic
        assertTrue(true); // Replace with actual verification
    }
}