package finalAssessment;

import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Leaderboard extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    public Leaderboard(String level) {
        setTitle("Leaderboard - " + level); // Set window title
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 587, 407);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Define Table Columns
        String[] columns = {"Rank", "Name", "Score", "No of Correct"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 10, 537, 259);
        contentPane.add(scrollPane);

        // Populate Table with Data
        loadLeaderboardData(level);
    }

    private void loadLeaderboardData(String level) {
        List<String[]> rankedPlayers = Competitor.rankScore(level);
        for (String[] playerData : rankedPlayers) {
            tableModel.addRow(playerData);
        }
    }
}
