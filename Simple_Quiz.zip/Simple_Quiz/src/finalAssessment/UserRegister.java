package finalAssessment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserRegister {

    public static void registerUser(String username, String password) {
        String salt = PasswordUtils.generateSalt(); // Generate a unique salt
        String hashedPassword = PasswordUtils.hashPassword(password, salt); // Hash the password

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, hashedPassword);
            stmt.setString(3, salt);
            stmt.executeUpdate();
            System.out.println("User registered successfully!");
        } catch (SQLException e) {
            System.err.println("Error registering user: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        registerUser("ram", "password");// Register a user
    }
}
