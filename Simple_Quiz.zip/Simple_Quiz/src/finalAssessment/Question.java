package finalAssessment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * The Question class represents a quiz question with its options and correct answer.
 */
public class Question {
    // Database connection constants
    static final String DB_URL = "jdbc:mysql//localhost:3306";
    static final String USER = "root"; 
    static final String PASS = "";

    private int id;
    private String question;
    private String option1;
    private String option2;
    private String option3;
    private String rightOption;

    /**
     * Constructs a Question object.
     *
     * @param id The unique identifier for the question.
     * @param question The text of the question.
     * @param option1 The first answer option.
     * @param option2 The second answer option.
     * @param option3 The third answer option.
     * @param rightOption The correct answer option.
     */
	    public Question(int id, String question, String option1, String option2, String option3, String rightOption) {
	        this.id = id;
	        this.question = question;
	        this.option1 = option1;
	        this.option2 = option2;
	        this.option3 = option3;
	        this.rightOption = rightOption;
	    }
	    public int getId() {
	        return id;
	    }

	    public String getQuestion() {
	        return question;
	    }

	    public String getOption1() {
	        return option1;
	    }

	    public String getOption2() {
	        return option2;
	    }

	    public String getOption3() {
	        return option3;
	    }

	    public String getRightOption() {
	        return rightOption;
	    }
	    public enum DifficultyLevel {
	        BEGINNER, INTERMEDIATE, ADVANCED
	    }
	    
	public static void save(String option1, String option2, String option3 , String right_option, DifficultyLevel difficulty_level, String question) {
        String query1 = "INSERT INTO questions (option1, option2, option3, right_option, difficulty_level, question) VALUES (?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            PreparedStatement pstm = conn.prepareStatement(query1);
            
            pstm.setString(1, option1);
            pstm.setString(2, option2);
            pstm.setString(3, option3);
            pstm.setString(4, right_option);
            pstm.setString(5, difficulty_level.name());   
            pstm.setString(6, question);

            int rowsAffected = pstm.executeUpdate();
            if(rowsAffected >0) {
            	System.out.println("Data inserted successfully!");
            }
            
            pstm.close();
            conn.close();
            
        }catch(SQLException e) {
        	 System.out.println("Database error: " + e.getMessage());
             e.printStackTrace();
        	
        }
        
	}
	
	 public static void list() {
	        String query = "SELECT * FROM questions";

	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query);
	             ResultSet rs = stmt.executeQuery()) {

	            while (rs.next()) {
	                int id = rs.getInt("id");
	                String option1 = rs.getString("option1");
	                String option2 = rs.getString("option2");
	                String option3 = rs.getString("option3");
	                String rightOption = rs.getString("right_option");
	                String difficultyLevel = rs.getString("difficulty_level");
	                 

	                System.out.println("ID: " + id);
	                System.out.println("Option 1: " + option1);
	                System.out.println("Option 2: " + option2);
	                System.out.println("Option 3: " + option3);
	                System.out.println("Correct Option: " + rightOption);
	                System.out.println("Difficulty Level: " + difficultyLevel);
	                System.out.println("----------------------------");
	            }

	        } catch (SQLException e) {
	            System.err.println("Error listing questions: " + e.getMessage());
	        }
	    }
	 
	 public static List<Question> levelQuestion(String difficultyLevel) {
		 String query2 = "SELECT * From questions where difficulty_level = ?";
		 List<Question> questionsList = new ArrayList<>();
		 
		 try(Connection conn =  DatabaseConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(query2) ){
		        stmt.setString(1, difficultyLevel);
		        ResultSet rs = stmt.executeQuery();
		        
		        while (rs.next()) {
		            int id = rs.getInt("id");
		            String question = rs.getString("question");
		            String option1 = rs.getString("option1");
		            String option2 = rs.getString("option2");
		            String option3 = rs.getString("option3");
		            String rightOption = rs.getString("right_option");
		            questionsList.add(new Question(id, question, option1, option2, option3, rightOption));

		            
		        }


		 }catch(SQLException e) {
		        System.err.println("Error executing query: " + e.getMessage());

		 }
		    return questionsList;

	 }
	 
	 public static void update(int id, String option1, String option2, String option3, String right_option, DifficultyLevel difficulty_level, String question ) {
	        String query = "UPDATE questions SET option1 = ?, option2 = ?, option3 = ?, right_option = ?, question = ?, difficulty_level = ? WHERE id = ? ";

	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {
	        	stmt.setString(1, option1);
	        	stmt.setString(2, option2);
	        	stmt.setString(3, option3);
	        	stmt.setString(4, right_option);
	        	stmt.setString(5, question); 
	        	stmt.setString(6, difficulty_level.name());
	        	stmt.setInt(7, id); 


	            int rowsAffected = stmt.executeUpdate(); 
	            if (rowsAffected > 0) {
	                System.out.println("Question updated successfully!");
	            } else {
	                System.out.println("Failed to update the question.");
	            }
	        } catch (SQLException e) {
	            System.err.println("Error updating question: " + e.getMessage());
	        }
	    }
	 
	 public static void delete(int id) {
	        String query = "DELETE FROM questions WHERE id = ?";

	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {

	            stmt.setInt(1, id);

	            int rowsAffected = stmt.executeUpdate();
	            if (rowsAffected > 0) {
	                System.out.println("Question deleted successfully!");
	            } else {
	                System.out.println("No question found with the given ID.");
	            }
	        } catch (SQLException e) {
	            System.err.println("Error deleting question: " + e.getMessage());
	        }
	    }
	
	public static void main(String[] args) {
        levelQuestion("beginner");
        
    } 
}


