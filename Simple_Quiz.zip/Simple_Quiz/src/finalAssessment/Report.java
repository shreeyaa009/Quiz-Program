package finalAssessment;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Report extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Report frame = new Report();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public Report() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 950, 415);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // Define Table Columns
        String[] columns = {"Name", "Beginner Score", "Intermediate Score", "Advanced Score"};
        tableModel = new DefaultTableModel(columns, 0);
        contentPane.setLayout(null);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(305, 10, 612, 301);
        contentPane.add(scrollPane);

        // Panel for Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(0, 26, 295, 150);
        
        JButton reportButton = new JButton("REPORT");
        reportButton.setBounds(0, 6, 130, 29);
        reportButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        reportButton.addActionListener(e -> listData());  // Call listData to populate the table
        buttonPanel.setLayout(null);
        buttonPanel.add(reportButton);

        JButton leaderboardButton = new JButton("LEADERBOARD");
        leaderboardButton.setBounds(0, 111, 196, 29);
        leaderboardButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        leaderboardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showLeaderboardDialog();
                
            }
        });
        buttonPanel.add(leaderboardButton);
        
        contentPane.add(buttonPanel);
    }
    
    public void listData() {
    	tableModel.setRowCount(0);
        String query = "SELECT user_name, beginner_score, intermediate_score, advance_score FROM players";
    	try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()){
    		 while (rs.next()) {
    			 String user_name = rs.getString("user_name");  // Assuming column name is 'user_name'
    			 int beginner_score = rs.getInt("beginner_score");
    			 int intermediate_score = rs.getInt("intermediate_score");
    			 int advance_score = rs.getInt("advance_score");
    			  tableModel.addRow(new Object[]{
    	                    user_name, beginner_score, intermediate_score, advance_score
    	                });}
    		
    		
    	}catch(SQLException e) {
            System.err.println("Error loading questions: " + e.getMessage());    		
    	}

    }

    private void showLeaderboardDialog() {
        JDialog dialog = new JDialog(this, "Select Level", true);
        dialog.setSize(300, 200);
        dialog.getContentPane().setLayout(new GridLayout(2, 1, 10, 10));
        
        String[] levels = {"Beginner", "Intermediate", "Advanced"};
        JComboBox<String> levelDropdown = new JComboBox<>(levels);
        dialog.getContentPane().add(levelDropdown);
        
        JButton applyButton = new JButton("Apply");
        applyButton.addActionListener(e -> {
//        	note for inserting in database
            String selectedLevel = (String) levelDropdown.getSelectedItem();
            dialog.dispose(); // Close the dialog
            
            // Open the Leaderboard JFrame with the selected level
            Leaderboard leaderboadFrame = new Leaderboard(selectedLevel);
            leaderboadFrame.setVisible(true);
            Competitor.rankScore(selectedLevel);
        });

        dialog.getContentPane().add(applyButton);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

}