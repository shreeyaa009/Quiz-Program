/**
 * 
 */
module JavaAssessmentProject {
    requires java.desktop; // Required for GUI components (Swing, AWT)
    requires java.sql;
	requires junit;
	requires org.junit.jupiter.api;     // Required for database connectivity
    
    exports finalAssessment; // Export the package containing your application classes
}